require_relative '../jenkins'

module Puppet::X::Jenkins::Type; end
