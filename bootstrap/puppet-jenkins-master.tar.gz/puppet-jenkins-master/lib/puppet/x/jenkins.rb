module Puppet::X; end
module Puppet::X::Jenkins; end
