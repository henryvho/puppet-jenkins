require 'puppet/util/feature'

Puppet.features.add(:retries, libs: 'retries')
